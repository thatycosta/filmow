
package dao;

import control.LeitorDeArquivo;
import control.EscritorDeArquivo;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import javax.swing.JOptionPane;
import model.Filme;

/**
 *
 * @author tauane
 */
public class FilmeDao implements Dao{
    private static final String ARQUIVO = "filme.txt";
    
    static {
        try {
            if (new File(ARQUIVO).createNewFile())
                System.out.println("arquivo "+ARQUIVO+" criado com sucesso");
            else
                System.out.println("arquivo "+ARQUIVO+" ja existe!");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public boolean inserir(Object obj) {
        ArrayList<Filme> filmes = pesquisarTodos();
        Filme filme = (Filme) obj;
        filme.setId(filmes.size() + 1);
        
        boolean filmeAdicionado = filmes.add((Filme) obj);
        if(filmeAdicionado){
            EscritorDeArquivo.write(filmes, ARQUIVO);
            JOptionPane.showMessageDialog(null,"Filme adicionado!");
        }
        else{
            JOptionPane.showMessageDialog(null,"Filme não foi adicionado!");
        }
        return filmeAdicionado;  
    }

    @Override
    public boolean atualizar(String titulo, Object obj) {
        ArrayList<Filme> filmes = pesquisarTodos();
        for(Filme filme : filmes){
            if(Objects.equals(filme.getTitulo(), titulo)){
                filmes.remove(filme);
                filmes.add((Filme)obj);
                EscritorDeArquivo.write(filmes, ARQUIVO);
                JOptionPane.showMessageDialog(null, "Filme foi atualizado!");
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "Filme não foi atualizado!");
        return false;
    }
    
    @Override
    public boolean excluir(String titulo){
        ArrayList<Filme> filmes = pesquisarTodos();
        for (Filme filme : filmes)
            if (Objects.equals(filme.getTitulo(), titulo))
                if (filmes.remove(filme)) {
                    EscritorDeArquivo.write(filmes, ARQUIVO);
                    JOptionPane.showMessageDialog(null, "Filme excluído!");
                    return true;
                }
        JOptionPane.showMessageDialog(null, "Filme não econtrado!");
        return false;
    }

    @Override
    public Filme pesquisar(String titulo){
        ArrayList<Filme> filmes = pesquisarTodos();
        for (Filme filme : filmes) {
            if(Objects.equals(filme.getTitulo(), titulo)){
                return filme;
            }
        }
        return null;
    }
    
    @Override
    public ArrayList pesquisarTodos() {
        ArrayList<Filme> filmes = (ArrayList) LeitorDeArquivo.read(ARQUIVO);
        if(filmes == null){
            return new ArrayList<>();
        }
        return filmes;
    }
    
}
