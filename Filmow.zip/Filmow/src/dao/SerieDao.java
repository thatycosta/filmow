
package dao;

import control.LeitorDeArquivo;
import control.EscritorDeArquivo;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import javax.swing.JOptionPane;
import model.Serie;

/**
 *
 * @author tauane
 */
public class SerieDao implements Dao{
    private static final String ARQUIVO = "serie.txt";
    
    static {
        try {
            if (new File(ARQUIVO).createNewFile())
                System.out.println("arquivo "+ARQUIVO+" criado com sucesso");
            else
                System.out.println("arquivo "+ARQUIVO+" ja existe!");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public boolean inserir(Object obj) {
        ArrayList<Serie> series = pesquisarTodos();
        Serie serie = (Serie) obj;
        serie.setId(series.size() + 1);
        
        boolean serieAdicionada = series.add((Serie) obj);
        if(serieAdicionada){
            EscritorDeArquivo.write(series, ARQUIVO);
            JOptionPane.showMessageDialog(null,"Série adicionada!");
        }
        else{
            JOptionPane.showMessageDialog(null,"Série não foi adicionada!");
        }
        return serieAdicionada;  
    }

    @Override
    public boolean atualizar(String titulo, Object obj) {
        ArrayList<Serie> series = pesquisarTodos();
        for(Serie serie : series){
            if(Objects.equals(serie.getTitulo(), titulo)){
                series.remove(serie);
                series.add((Serie)obj);
                EscritorDeArquivo.write(series, ARQUIVO);
                JOptionPane.showMessageDialog(null, "Série foi atualizada!");
                return true;
            }
        }
        JOptionPane.showMessageDialog(null, "Série não foi atualizada!");
        return false;
    }
    
    @Override
    public boolean excluir(String titulo){
        ArrayList<Serie> series = pesquisarTodos();
        for (Serie serie : series)
            if (Objects.equals(serie.getTitulo(), titulo))
                if (series.remove(serie)) {
                    EscritorDeArquivo.write(series, ARQUIVO);
                    JOptionPane.showMessageDialog(null, "Série excluída!");
                    return true;
                }
        JOptionPane.showMessageDialog(null, "Série não econtrada!");
        return false;
    }

    @Override
    public Serie pesquisar(String titulo){
        ArrayList<Serie> series = pesquisarTodos();
        for (Serie serie : series) {
            if(Objects.equals(serie.getTitulo(), titulo)){
                return serie;
            }
        }
        return null;
    }
    
    @Override
    public ArrayList pesquisarTodos() {
        ArrayList<Serie> series = (ArrayList) LeitorDeArquivo.read(ARQUIVO);
        if(series == null){
            return new ArrayList<>();
        }
        return series;
    }
    
}
