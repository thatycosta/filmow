
package dao;

import java.util.ArrayList;

/**
 *
 * @author tauane
 */

public interface Dao {
    boolean inserir(Object obj);
    boolean atualizar(String titulo, Object obj);
    boolean excluir(String titulo);
    Object pesquisar(String titulo);
    ArrayList pesquisarTodos();

}
