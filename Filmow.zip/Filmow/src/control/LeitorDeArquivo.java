package control;

import java.io.*;

/**
 *
 * @author tauane
 */

public class LeitorDeArquivo {
    public static Object read(String filePath) {
        Object object = null;
        try(
            FileInputStream fi = new FileInputStream(filePath);
            ObjectInputStream input = new ObjectInputStream(fi);
        ){
            object = input.readObject();
        } catch(ClassNotFoundException ex){
            System.out.println("Classe não encontrada: " + ex);
        } catch(EOFException ex){
            return object;
        } catch(IOException ex){
            System.out.println("Não pode ler o arquivo: " + filePath + "): " + ex);
        }
        return object;
    }
}
