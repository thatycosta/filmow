package control;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author tauane
 */

public class EscritorDeArquivo {
    public static void write(Object object, String filePath){
        try(
                FileOutputStream fo = new FileOutputStream(filePath);
                ObjectOutputStream output = new ObjectOutputStream(fo);
        ){
            output.writeObject(object);
        }catch(IOException ex){
            System.out.println("Não pode ler " + filePath + ": "+ ex);
        }

    }
}
