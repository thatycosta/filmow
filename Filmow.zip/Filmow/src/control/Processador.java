
package control;

import java.io.IOException;
import javax.swing.JOptionPane;
import view.InterfaceEditarFilme;
import view.InterfaceEditarSerie;
import view.InterfaceExcluirFilme;
import view.InterfaceExcluirSerie;
import view.InterfaceInserirFilme;
import view.InterfaceInserirSerie;
import view.InterfaceListarFilmes;
import view.InterfaceListarSeries;
import view.InterfacePesquisarFilme;
import view.InterfacePesquisarSerie;

/**
 *
 * @author tauane
 */

public class Processador {
    
    
    public static void exibeMenu() throws IOException, ClassNotFoundException{
   
        int operador = 0;
        
        do{
            operador = Integer.parseInt(JOptionPane.showInputDialog( null, 
            "Filmow - Catalogação de Filmes e Séries\n\n"
            + "           Filmow - Opções\n\n"
            + " 1  - Inserir Filme \n"
            + " 2  - Inserir Série \n"
            + " 3  - Editar Filme\n"
            + " 4  - Editar Série\n"
            + " 5  - Excluir Filme\n"
            + " 6  - Excluir Série\n"
            + " 7  - Pesquisar Filme\n"
            + " 8  - Pesquisar Série\n"
            + " 9  - Listar Filmes\n"
            + " 10 - Listar Séries\n"
            + " 11  - Sair\n"));
            switch(operador){
                case 1:
                    InterfaceInserirFilme.executar();
                    break;
                case 2:
                    InterfaceInserirSerie.executar();
                    break;
                case 3:
                    InterfaceEditarFilme.executar();
                    break;
                case 4:
                    InterfaceEditarSerie.executar();
                    break;
                case 5:
                    InterfaceExcluirFilme.executar();
                    break;
                case 6:
                    InterfaceExcluirSerie.executar();
                    break;
                case 7:
                    InterfacePesquisarFilme.executar();
                    break;
                case 8:
                    InterfacePesquisarSerie.executar();
                    break;
                case 9:
                    InterfaceListarFilmes.executar();
                    break;
                case 10:
                    InterfaceListarSeries.executar();
                    break;
                case 11:
                    break;
                }

            }while(operador != 11);
    }
    
    
    
}
