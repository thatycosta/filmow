package view;


import java.io.IOException;
import javax.swing.JOptionPane;
import control.Processador;

/**
 *
 * @author tauane
 */

public class Principal {

    private static String nomeCatalogo;

    public static void main(String[] args) throws IOException, ClassNotFoundException {
      
        JOptionPane.showMessageDialog(null, "Bem vindo ao Filmow - Catálogo de Filmes e Séries!");
        JOptionPane.showMessageDialog(null, "Redirecionando ao menu...");
        Processador.exibeMenu();
        JOptionPane.showMessageDialog(null, "Saindo...");
    }
}
