/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import dao.FilmeDao;
import javax.swing.JOptionPane;

/**
 *
 * @author tauane
 */
public class InterfaceListarFilmes {
    static FilmeDao fdao = new FilmeDao();
    
    public static void executar(){
        JOptionPane.showMessageDialog(null, "Filmes:\n" + fdao.pesquisarTodos());
    }
    
    
}
