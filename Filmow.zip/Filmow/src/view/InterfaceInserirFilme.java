/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import javax.swing.JOptionPane;
import model.Diretor;
import model.Genero;
import java.io.IOException;
import dao.FilmeDao;
import model.Filme;
import model.Oscar;

/**
 *
 * @author tauane
 */
public class InterfaceInserirFilme {
    
    static String titulo = null;
    static int duracao = 0;
    static int id = 0;
    static String premio = null;
    static String nomeDiretor = null;
    static int ano = 0;
    static Genero escolheGenero = null;
    static int ganhouPremio = 0;
    
    public static void executar() throws IOException, ClassNotFoundException{
        
        FilmeDao fdao = new FilmeDao();
        
        titulo = JOptionPane.showInputDialog(null, "Informe o titulo do filme: ");
        ganhouPremio = Integer.parseInt(JOptionPane.showInputDialog(null, "Esse"
                + " filme ganhou o Oscar?:\n 1 - Sim\n 2 - Não\n"));
        if(ganhouPremio == 1){
        premio = JOptionPane.showInputDialog(null, "Informe o premio que o filme ganhou: ");
        }
        else{
            premio = "não ganhou nenhum prêmio";
        }
        duracao = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a duração do filme: "));
        nomeDiretor = JOptionPane.showInputDialog(null, "Informe o nome do diretor deste filme: ");
        ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ano em que foi filmado: "));
        Object[] dados = Genero.values();
            escolheGenero = (Genero) JOptionPane.showInputDialog(
                    null,
                    "Genero:\n",
                    "Escolha o genero",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    dados,
                    Genero.SUSPENSE);
        
    Oscar oscar = new Oscar(premio);
    Diretor diretor = new Diretor(nomeDiretor);
    Filme filme = new Filme(duracao, oscar, titulo, diretor, ano, escolheGenero);
    fdao.inserir(filme);
    }
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
