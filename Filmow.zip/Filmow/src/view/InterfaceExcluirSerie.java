/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import dao.FilmeDao;
import dao.SerieDao;
import javax.swing.JOptionPane;

/**
 *
 * @author tauane
 */
public class InterfaceExcluirSerie {
       
    static String seriePesquisa;
    static SerieDao sdao = new SerieDao();
    
    public static void executar() {
       
        seriePesquisa = JOptionPane.showInputDialog(null, "Qual o nome da série "
                + "que você deseja pesquisar? ");
        JOptionPane.showMessageDialog(null, "Séries:\n" + sdao.excluir(seriePesquisa));
        
    }

    
}
