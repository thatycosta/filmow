    
package model;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author tauane
 */

public abstract class ProdutoAudiovisual implements Serializable {

    private int id;
    private String titulo;
    private Diretor diretor;
    private int ano;
    private Genero genero;
    private boolean isPremiado;
    
    
    public ProdutoAudiovisual(int id, String titulo, Diretor diretor, 
            int ano, Genero genero){
        this.id = id;
        this.titulo = titulo;
        this.diretor = diretor;
        this.ano = ano;
        this.genero = genero;
    }
    
    public ProdutoAudiovisual(String titulo){
        this.titulo = titulo;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Diretor getDiretor() {
        return diretor;
    }

    public void setDiretor(Diretor diretor) {
        this.diretor = diretor;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.titulo);
        hash = 67 * hash + Objects.hashCode(this.diretor);
        hash = 67 * hash + this.ano;
        hash = 67 * hash + Objects.hashCode(this.genero);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ProdutoAudiovisual other = (ProdutoAudiovisual) obj;
        if (!Objects.equals(this.titulo, other.titulo)) {
            return false;
        }
        if (!Objects.equals(this.diretor, other.diretor)) {
            return false;
        }
        if (this.ano != other.ano) {
            return false;
        }
        if (this.genero != other.genero) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Id - " + this.getId() + "\n" 
                + " titulo = " + this.getTitulo() + "\n"
                + " diretor = " + diretor + "\n"
                + " ano = " + this.getAno() + "\n"
                + " genero = " + genero + "\n";
    }
    
    
    
    
}
