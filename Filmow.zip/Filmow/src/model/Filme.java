
package model;

import java.util.Objects;

/**
 *
 * @author tauane
 */

public class Filme extends ProdutoAudiovisual {

    private int duracao;
    private Oscar oscar;

    public Filme(int id, int duracao, Oscar oscar, String titulo, 
            Diretor diretor, int ano, Genero genero) {
        super(id, titulo, diretor, ano, genero);
        this.duracao = duracao;
        this.oscar = oscar;
    }

    public Filme(int duracao, Oscar oscar, String titulo, Diretor diretor, 
            int ano, Genero genero) {
        this(0, duracao, oscar, titulo, diretor, ano, genero);
    }
    
    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public Oscar getOscar() {
        return oscar;
    }

    public void setOscar(Oscar oscar) {
        this.oscar = oscar;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 83 * hash + this.duracao;
        hash = 83 * hash + Objects.hashCode(this.oscar);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Filme other = (Filme) obj;
        if (this.duracao != other.duracao) {
            return false;
        }
        if (!Objects.equals(this.oscar, other.oscar)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return  super.toString()
                + " duracao = " + this.getDuracao() + "\n"   
                + " oscar = " + oscar + "\n";
    }

 
        
}
