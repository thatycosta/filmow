package model;

import java.util.Objects;

/**
 *
 * @author tauane
 */

public class Serie extends ProdutoAudiovisual {

    private int id;
    private int temporadas;
    private Emmy emmy;

    public Serie(int id, int temporadas, Emmy emmy, String titulo, 
            Diretor diretor, int ano, Genero genero) {
        super(id, titulo, diretor, ano, genero);
        this.id = id;
        this.temporadas = temporadas;
        this.emmy = emmy;
    }
    
    public Serie(int temporadas, Emmy emmy, String titulo, Diretor diretor, 
            int ano, Genero genero) {
        this(0, temporadas, emmy, titulo, diretor, ano, genero);
    }

    public int getTemporadas() {
        return temporadas;
    }

    public void setTemporadas(int temporadas) {
        this.temporadas = temporadas;
    }

    public Emmy getEmmy() {
        return emmy;
    }

    public void setEmmy(Emmy emmy) {
        this.emmy = emmy;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + this.id;
        hash = 71 * hash + this.temporadas;
        hash = 71 * hash + Objects.hashCode(this.emmy);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Serie other = (Serie) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.temporadas != other.temporadas) {
            return false;
        }
        if (!Objects.equals(this.emmy, other.emmy)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return  super.toString()
                + " temporadas = " + this.getTemporadas() + "\n"   
                + " emmy = " + emmy + "\n";
    }    
}
