
package model;

import java.io.Serializable;

/**
 *
 * @author tauane
 */

public enum Genero implements Serializable{

    TERROR, 
    ACAO, 
    DRAMA, 
    MUSICAL, 
    COMEDIA, 
    SUSPENSE, 
    AVENTURA, 
    FICCAO, 
    FAROESTE;

    
}
